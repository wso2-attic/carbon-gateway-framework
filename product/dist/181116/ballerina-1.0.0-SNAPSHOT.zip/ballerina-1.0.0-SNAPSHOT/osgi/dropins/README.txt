This directory contains all OSGi bundles that should be added to Carbon, copy
those into this directory.